import express from "express";
import multer from "multer";
import fetch from "node-fetch";
import FormData from "form-data";
import cors from "cors";

const app = express();
app.use(cors());

const upload = multer();

// 🔐 Put your Pinata JWT here
const PINATA_JWT = "YOUR_PINATA_JWT";

app.post("/upload", upload.single("file"), async (req, res) => {
  try {
    const data = new FormData();
    data.append("file", req.file.buffer, req.file.originalname);

    const response = await fetch(
      "https://api.pinata.cloud/pinning/pinFileToIPFS",
      {
        method: "POST",
        headers: {
          Authorization: `Bearer ${PINATA_JWT}`,
        },
        body: data,
      }
    );

    const result = await response.json();

    res.json(result);

  } catch (err) {
    console.error(err);
    res.status(500).send("Upload failed");
  }
});

app.listen(3000, () => console.log("Server running on port 3000"));